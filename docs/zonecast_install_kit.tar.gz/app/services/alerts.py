"""
Attention-grabbing alerts shown once per session on first dashboard
load (Sistema-adjacent, but relevant to every admin) — currently:
recent failed scheduled playbacks, and disk space running low.
Read-only and cheap enough to compute on every login.
"""
from dataclasses import dataclass, field
from datetime import timedelta

from sqlalchemy.orm import Session

from . import host_resources
from ..models import PlaybackLog, PlaybackSource, PlaybackStatus, Speaker
from ..timeutil import utcnow

FAILED_PLAYBACK_LOOKBACK = timedelta(hours=24)
DISK_WARNING_PERCENT = 75.0
DISK_DANGER_PERCENT = 90.0


@dataclass
class Alert:
    severity: str  # "warning" | "danger"
    code: str      # translated by the dashboard as t('alert.' + code, params)
    message: str   # English fallback
    params: dict = field(default_factory=dict)


def get_alerts(db: Session) -> list[Alert]:
    alerts: list[Alert] = []

    cutoff = utcnow() - FAILED_PLAYBACK_LOOKBACK
    failed_count = (
        db.query(PlaybackLog)
        .filter(
            PlaybackLog.source == PlaybackSource.schedule,
            PlaybackLog.status == PlaybackStatus.failed,
            PlaybackLog.started_at >= cutoff,
        )
        .count()
    )
    if failed_count:
        alerts.append(Alert(
            severity="danger",
            code="failed_playbacks",
            message=f"{failed_count} schedule playback(s) failed in the last 24 hours — check the Log tab.",
            params={"count": failed_count},
        ))

    # A push queued moments ago is still "pending", not a problem yet.
    recent = utcnow() - timedelta(minutes=10)
    out_of_sync = (
        db.query(Speaker)
        .filter(Speaker.paging_sync_ok.is_(False))
        .filter((Speaker.paging_sync_error != "pending") | (Speaker.updated_at < recent))
        .count()
    )
    if out_of_sync:
        alerts.append(Alert(
            severity="warning",
            code="speakers_out_of_sync",
            message=f"{out_of_sync} speaker(s) didn't accept their latest zone setup: check the Speakers tab.",
            params={"count": out_of_sync},
        ))

    from . import overlap
    overlaps = len(overlap.all_pairs(db))
    if overlaps:
        alerts.append(Alert(
            severity="warning",
            code="schedule_overlaps",
            message=f"{overlaps} pair(s) of schedules play on the same speakers at the same time: check the Schedules tab.",
            params={"count": overlaps},
        ))

    from . import auto_backup
    for severity, code, message, params in auto_backup.alerts(db):
        alerts.append(Alert(severity=severity, code=code, message=message, params=params))

    try:
        disk_percent = host_resources.get_snapshot(cpu_sample_seconds=0.0).disk_percent
    except host_resources.HostResourcesError:
        disk_percent = None
    if disk_percent is not None:
        if disk_percent >= DISK_DANGER_PERCENT:
            alerts.append(Alert(severity="danger", code="disk_critical",
                                message=f"Disk space is critically low ({disk_percent:.0f}% used).",
                                params={"percent": f"{disk_percent:.0f}"}))
        elif disk_percent >= DISK_WARNING_PERCENT:
            alerts.append(Alert(severity="warning", code="disk_low",
                                message=f"Disk space is running low ({disk_percent:.0f}% used).",
                                params={"percent": f"{disk_percent:.0f}"}))

    return alerts
