"""
Brings the database schema up to date at every startup, before anything
else touches the tables — so a release that changes the schema just
works after the code is updated and the service restarted, on the
native install, on Docker and after importing a bundle from an older
version (see services/pending_import.py). Maintenance tools that open
the database (seed_sample_media, reset_admin_password) call it too.

Databases created before Alembic was wired in (every install up to
v1.5.7) have all the tables but no alembic_version row: they already
match the 0001 baseline, so they're stamped there first and then
upgraded like any other.
"""
import logging
import sqlite3
from pathlib import Path

from alembic import command
from alembic.config import Config
from alembic.script import ScriptDirectory
from sqlalchemy import create_engine, event, inspect
from sqlalchemy.pool import NullPool

from .config import BASE_DIR, settings
from .timeutil import utcnow

logger = logging.getLogger("zonecast.migrate")
BASELINE_REVISION = "0001"
# Tables every pre-Alembic install has (create_all ran at each start).
BASELINE_TABLES = {
    "users", "zones", "speakers", "media", "schedules", "playback_logs",
    "app_settings", "event_logs", "speaker_config_backups",
}


def _migration_engine():
    """A private engine whose single transaction covers the whole
    stamp + upgrade. pysqlite would otherwise commit each DDL statement
    on its own, so a crash or kill mid-way left a half-migrated schema
    that failed every later start. BEGIN IMMEDIATE also takes SQLite's
    write lock up front: the service and a maintenance tool starting at
    the same moment migrate one after the other, not on top of each
    other."""
    engine = create_engine(settings.database_url, poolclass=NullPool)
    if engine.dialect.name == "sqlite":
        @event.listens_for(engine, "connect")
        def _connect(dbapi_connection, _record):
            dbapi_connection.isolation_level = None  # we issue BEGIN ourselves
            dbapi_connection.execute("PRAGMA journal_mode=WAL")
            dbapi_connection.execute("PRAGMA busy_timeout=30000")

        @event.listens_for(engine, "begin")
        def _begin(connection):
            connection.exec_driver_sql("BEGIN IMMEDIATE")
    return engine


def _config(connection) -> Config:
    cfg = Config(str(BASE_DIR / "alembic.ini"))
    # ConfigParser interpolation: a literal % in the path must be doubled.
    cfg.set_main_option("script_location", str(BASE_DIR / "migrations").replace("%", "%%"))
    cfg.attributes["connection"] = connection
    cfg.attributes["skip_logging_config"] = True
    return cfg


def _is_pre_alembic(connection, tables: set[str]) -> bool:
    if not tables:
        return False  # empty DB: the 0001 migration creates everything
    if "alembic_version" not in tables:
        return True
    # An alembic_version table left empty by an interrupted stamp.
    return not connection.exec_driver_sql("SELECT version_num FROM alembic_version").fetchall()


# Copies of the database taken right before a schema upgrade.
KEEP_PRE_UPGRADE_SNAPSHOTS = 3


def head_revision() -> str:
    return ScriptDirectory.from_config(_config(None)).get_current_head()


def is_known_revision(revision: str) -> bool:
    try:
        return ScriptDirectory.from_config(_config(None)).get_revision(revision) is not None
    except Exception:  # alembic raises several types for an unknown id
        return False


def _stored_revision(db_path) -> str | None:
    """The revision recorded in the database file, read without taking
    any lock; None for an empty or pre-Alembic database."""
    # as_uri() percent-encodes the path: a '%' or '#' in a folder name
    # would otherwise change which file SQLite opens.
    con = sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True)
    try:
        if not con.execute("SELECT 1 FROM sqlite_master WHERE name = 'alembic_version'").fetchone():
            has_tables = con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table'").fetchone()
            return "legacy" if has_tables else None
        row = con.execute("SELECT version_num FROM alembic_version").fetchone()
        return row[0] if row else "legacy"
    finally:
        con.close()


def _snapshot_before_upgrade() -> bool:
    """A schema upgrade rewrites tables in place: keep a copy of the
    database as it was, next to it, in case the new version has to be
    rolled back. Returns whether a copy was made."""
    db_path = settings.db_path
    if not settings.database_url.startswith("sqlite") or not db_path.exists():
        return False
    revision = _stored_revision(db_path)
    if revision is None or revision == head_revision():
        return False
    if revision != "legacy" and not is_known_revision(revision):
        # Written by a newer ZoneCast (this code was rolled back): no
        # upgrade is possible, and copying it at every restart of the
        # failing service would rotate the real rollback copy away.
        raise RuntimeError(
            f"Il database è alla revisione {revision}, più recente di questa versione di ZoneCast "
            f"(ultima revisione nota: {head_revision()}): reinstallare la versione più recente, "
            "oppure ripristinare la copia zonecast.db.pre-upgrade-* presa prima dell'aggiornamento")
    from .services.bundle import _snapshot_sqlite

    target = db_path.with_name(f"{db_path.name}.pre-upgrade-{revision}-{utcnow():%Y%m%dT%H%M%SZ}")
    target.write_bytes(_snapshot_sqlite(db_path))
    logger.warning("Aggiornamento dello schema da %s: copia del database salvata in %s", revision, target)
    return True


def _prune_snapshots() -> None:
    """Only after an upgrade succeeded: a start that keeps failing must
    never rotate away the copy it would be rolled back to."""
    db_path = settings.db_path
    old = sorted(db_path.parent.glob(f"{db_path.name}.pre-upgrade-*"), key=lambda p: p.stat().st_mtime)
    for path in old[:-KEEP_PRE_UPGRADE_SNAPSHOTS]:
        path.unlink(missing_ok=True)


def run_migrations() -> None:
    snapshot_taken = _snapshot_before_upgrade()
    engine = _migration_engine()
    try:
        with engine.begin() as connection:
            tables = set(inspect(connection).get_table_names())
            cfg = _config(connection)
            if _is_pre_alembic(connection, tables):
                missing = BASELINE_TABLES - tables
                if missing:
                    raise RuntimeError(
                        "Database pre-Alembic incompleto (mancano le tabelle: "
                        f"{', '.join(sorted(missing))}): ripristinare un backup o un export completo"
                    )
                logger.info("Database pre-Alembic: registro la baseline %s", BASELINE_REVISION)
                command.stamp(cfg, BASELINE_REVISION)
            command.upgrade(cfg, "head")
    finally:
        engine.dispose()
    if snapshot_taken:
        _prune_snapshots()
